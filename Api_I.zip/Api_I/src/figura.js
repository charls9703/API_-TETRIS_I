const express = require("express");
const app = express();
const morgan = require("morgan");

/**
 * configuracion
 */
app.set("port", process.env.PORT || 3000);
app.set("hostname", process.env.HOST || "142.44.246.92");
/**
 * middelware
 */
app.use(morgan("dev"));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

/**
 * se crea un objeto con dos propiedades
 * las cuales tienen su valores correspondientes
 */
const player = {
  pos: { x: 0, y: 0 },
  matriz: [
    [0, 1, 0, 0],
    [0, 1, 0, 0],
    [0, 1, 0, 0],
    [0, 1, 0, 0],
  ],
};

/**
   * girar la matriz de la figura
   * @param {object} matriz -recibe la matriz que se ha creado en el objeto player
   */
  function rotate(matriz) {
    for (let y = 0; y < matriz.length; y++) {
      for (let x = 0; x < y; x++) {
        [matriz[x][y], matriz[y][x]] = [matriz[y][x], matriz[x][y]];
      }
    }
    matriz.forEach((row) => row.reverse());
  }

/**
   * funcion que mueve la matriz de izquierda a derecha
   * @param {number} directionX -valor que determina
   * hacia que lado se va a dirigir:
   *  (-1) izquierda,
   *  (1) derecha
   * @param {number} directionY -valor alamcenado solo para
   * mostrar la posicion  que tiene en y
   *
   */
  function playerMove(directionX, directionY) {
    player.pos.x += directionX;
    player.pos.y = directionY;
  }

/**
   *
   * @param {number} drop -variable que almacena
   * la posicion en (Y) y la aumenta una vez
   */
  function playerDrop(drop) {
    player.pos.y = drop;
    player.pos.y++;
  }

/**
 * ruta para visualizar la matriz y sus posiciones iniciales
 * por medio de la peticion get
 */
app.get("/matriz", (req, res) => {
  res.json(player);
});
/**
 * ruta para rotar la matriz 90°
 * por medio de la peticion get
 */
app.get("/rotate", (req, res) => {
  const { pos, matriz } = req.body;
  //console.log(req.body);
  if (pos && matriz) {
    const posi = { ...req.body };
    rotate(posi.matriz);
    res.json(posi);
  }
  
});
/**
 * ruta para mover la figura de
 * izquierda a derecha por medio de la peticion post,
 * guardando la posicion en la que esta y sumando
 * el numero de posiciones que sequiere mover
 */
app.post("/move", (req, res) => {
  const { pos } = req.body;
  //console.log(req.body);
  if (pos) {
    var posi = { ...req.body };
    playerMove(posi.pos.x, posi.pos.y);
    res.json(player);
  }
});
/**
 * ruta para mover la pieza hacia abajo
 * utilizabdo la peticion post
 * guardando la posicion en la que esta y bajando un movimiento a la vez
 */
app.post("/drop", (req, res) => {
  const { pos } = req.body;
  if (pos) {
    var posi = { ...req.body };
    playerDrop(posi.pos.y);
    res.json(player);
  }
});

/**
 * iniciar servidor
 */
app.listen(app.get("port"), app.get("hostname"), () => {
  console.log(
    `Server running at http://${app.get("hostname")}:${app.get("port")}/`
  );
});
